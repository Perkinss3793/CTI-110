import sqlite3

# Connect to SQLite database file (creates file if it doesn't exist)
conn = sqlite3.connect("signup_hw.db")
cursor = conn.cursor()

# Drop table so script can be re-run cleanly in class
cursor.execute("DROP TABLE IF EXISTS users")

# STUDENT CODE GOES IN THIS SECTION ONLY!!!
#--------------------------------------------------------------------------------------
# STEP 1: Create users table
# TO DO: Create a table called users with fields
# user_id, first_name, last_name, email, username, password_hash, signup_date, country, age
# I have started the table for you with the primary key 'user_id'
cursor.execute("""
CREATE TABLE users (
    user_id INTEGER PRIMARY KEY,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    email TEXT UNIQUE,
    username TEXT NOT NULL,
    password_hash TEXT NOT NULL UNIQUE,
    signup_date DATE NOT NULL,
    country TEXT,
    age INTEGER
)""")

# STEP 2: Insert sample fake users
# TO DO: Create a list called users that will store all 10 of your fake users information.
# I have started it for you

users = [('Naruto', 'Uzamaki', 'ramen@example.com', 'LoveRamen1', '12345a', '2026-06-01', 'JAPAN', 16),
         ('Bob', 'Smith', 'abc@example.com','LoveRamen2', '12ab', '2026-06-02', 'USA', 25),
         ('Larry', 'Smith', 'ccc@example.com','LoveRamen3', 'help123', '2026-06-03', 'USA', 50),
         ('Susan', 'Wells', 'thankyou@example.com','LoveRamen4', '1234abb', '2026-06-04', 'Canada', 29),
         ('Tammy', 'Gerold', 'tammy@example.com','LoveRamen5', 'aabbcc1', '2026-06-05', 'USA', 19),
         ('Sara', 'Johnson', 'sara@example.com','LoveRamen6', 'eitherway1', '2026-06-06', 'Brazil', 44),
         ('Nick', 'Jones', 'nick@example.com','LoveRamen7', 'nick12345', '2026-06-02', 'USA', 25),
         ('Nicole', 'Sons', 'nicole@example.com','LoveRamen8', 'happyday2', '2026-06-08', 'JAPAN', 33),
         ('Brittany', 'Graves', 'graves@example.com','LoveRamen9', 'graves1234', '2026-06-09', 'USA', 70),
         ('Derick', 'Yates', 'yates@example.com','LoveRamen10', 'yatesd555', '2026-06-10', 'USA', 25)]


#------------------------------------------------------------------------------------
# DO NOT CODE PASS HERE!!!
# STEP 3: Run the python script! Once your done creating your table and adding in the user information
# You should run the program and it will create your database called signup_hw.db.
# You can then view it in your terminal and you can upload the .db file to a database viewer thats provided on Canvas.

cursor.executemany("""
INSERT INTO users (
    first_name, last_name, email, username, password_hash,
    signup_date, country, age
) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
""", users)

conn.commit()
conn.close()

print("✅ signup_hw.db created with users table and sample data.")

print()

conn = sqlite3.connect("signup_hw.db")
cur = conn.cursor()
for row in cur.execute("SELECT * FROM users LIMIT 10"):
    print(row)
conn.close()